schedule function misato:tick_139 1t
