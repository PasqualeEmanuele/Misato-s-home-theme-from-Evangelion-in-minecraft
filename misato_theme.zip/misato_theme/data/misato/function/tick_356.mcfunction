schedule function misato:tick_357 1t
