schedule function misato:tick_484 1t
