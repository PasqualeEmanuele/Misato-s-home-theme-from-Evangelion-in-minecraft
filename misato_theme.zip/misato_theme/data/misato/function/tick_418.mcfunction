schedule function misato:tick_419 1t
