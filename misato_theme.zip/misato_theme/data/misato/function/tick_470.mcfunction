playsound minecraft:block.note_block.bass block @a ~ ~ ~ 1.0 0.5297
playsound minecraft:block.note_block.basedrum block @a ~ ~ ~ 1.0 0.7071
schedule function misato:tick_471 1t
