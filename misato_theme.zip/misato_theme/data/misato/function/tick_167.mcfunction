schedule function misato:tick_168 1t
