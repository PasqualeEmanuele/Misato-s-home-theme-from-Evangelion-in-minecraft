schedule function misato:tick_476 1t
