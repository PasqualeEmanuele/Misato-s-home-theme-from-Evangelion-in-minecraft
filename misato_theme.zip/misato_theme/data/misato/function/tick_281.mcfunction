playsound minecraft:block.note_block.bass block @a ~ ~ ~ 1.0 0.5946
playsound minecraft:block.note_block.flute block @a ~ ~ ~ 1.0 0.8409
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 1.0 1.6818
playsound minecraft:block.note_block.basedrum block @a ~ ~ ~ 0.9 0.7071
playsound minecraft:block.note_block.hat block @a ~ ~ ~ 0.72 1.4142
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.8 1.7818
schedule function misato:tick_282 1t
