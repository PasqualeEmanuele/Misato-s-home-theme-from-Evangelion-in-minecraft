schedule function misato:tick_309 1t
