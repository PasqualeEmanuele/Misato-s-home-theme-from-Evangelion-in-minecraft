playsound minecraft:block.note_block.harp block @a ~ ~ ~ 1.0 1.4142
playsound minecraft:block.note_block.basedrum block @a ~ ~ ~ 0.9 0.7071
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.8 1.7818
schedule function misato:tick_394 1t
