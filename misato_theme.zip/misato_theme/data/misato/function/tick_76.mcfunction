schedule function misato:tick_77 1t
