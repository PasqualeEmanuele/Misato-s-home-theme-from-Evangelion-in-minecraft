schedule function misato:tick_288 1t
