schedule function misato:tick_492 1t
