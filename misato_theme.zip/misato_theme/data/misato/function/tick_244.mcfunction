schedule function misato:tick_245 1t
