schedule function misato:tick_227 1t
