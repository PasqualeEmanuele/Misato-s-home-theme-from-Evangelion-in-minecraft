playsound minecraft:block.note_block.flute block @a ~ ~ ~ 0.64 0.9439
schedule function misato:tick_178 1t
