schedule function misato:tick_380 1t
