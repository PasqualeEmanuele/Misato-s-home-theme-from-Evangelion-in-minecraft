schedule function misato:tick_404 1t
