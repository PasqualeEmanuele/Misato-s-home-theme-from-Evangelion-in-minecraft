playsound minecraft:block.note_block.bass block @a ~ ~ ~ 1.0 0.5297
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.79 0.63
playsound minecraft:block.note_block.basedrum block @a ~ ~ ~ 0.91 1.1892
schedule function misato:tick_386 1t
