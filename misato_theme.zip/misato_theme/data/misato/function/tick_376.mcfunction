schedule function misato:tick_377 1t
