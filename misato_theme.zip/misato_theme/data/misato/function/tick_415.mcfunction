schedule function misato:tick_416 1t
