schedule function misato:tick_493 1t
