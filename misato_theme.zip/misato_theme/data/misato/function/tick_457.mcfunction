playsound minecraft:block.note_block.bass block @a ~ ~ ~ 1.0 0.5297
playsound minecraft:block.note_block.flute block @a ~ ~ ~ 1.0 0.8909
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 0.93 1.7818
playsound minecraft:block.note_block.harp block @a ~ ~ ~ 1.0 0.5297
playsound minecraft:block.note_block.harp block @a ~ ~ ~ 0.76 0.5297
playsound minecraft:block.note_block.harp block @a ~ ~ ~ 0.76 0.7071
playsound minecraft:block.note_block.basedrum block @a ~ ~ ~ 0.9 0.7071
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.8 1.7818
schedule function misato:tick_458 1t
