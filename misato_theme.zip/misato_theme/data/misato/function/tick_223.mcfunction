schedule function misato:tick_224 1t
