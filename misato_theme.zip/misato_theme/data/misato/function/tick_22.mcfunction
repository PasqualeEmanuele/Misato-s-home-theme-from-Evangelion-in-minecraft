schedule function misato:tick_23 1t
