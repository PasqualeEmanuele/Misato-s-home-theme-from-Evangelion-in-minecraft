schedule function misato:tick_130 1t
