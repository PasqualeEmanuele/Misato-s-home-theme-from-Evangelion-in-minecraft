playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.5 0.63
schedule function misato:tick_254 1t
