schedule function misato:tick_348 1t
