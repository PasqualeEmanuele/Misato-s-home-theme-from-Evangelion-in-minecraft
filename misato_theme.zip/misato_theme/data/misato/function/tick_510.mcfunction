playsound minecraft:block.note_block.bass block @a ~ ~ ~ 1.0 0.7071
playsound minecraft:block.note_block.flute block @a ~ ~ ~ 1.0 0.63
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 0.93 1.2599
playsound minecraft:block.note_block.harp block @a ~ ~ ~ 0.8 0.7937
playsound minecraft:block.note_block.harp block @a ~ ~ ~ 1.0 0.7071
playsound minecraft:block.note_block.basedrum block @a ~ ~ ~ 1.0 0.7071
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.61 1.4142
schedule function misato:tick_511 1t
