schedule function misato:tick_389 1t
