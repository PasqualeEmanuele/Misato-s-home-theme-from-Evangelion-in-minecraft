schedule function misato:tick_340 1t
