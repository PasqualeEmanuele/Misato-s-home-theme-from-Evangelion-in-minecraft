schedule function misato:tick_2 1t
