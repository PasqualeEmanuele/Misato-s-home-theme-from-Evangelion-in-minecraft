schedule function misato:tick_34 1t
