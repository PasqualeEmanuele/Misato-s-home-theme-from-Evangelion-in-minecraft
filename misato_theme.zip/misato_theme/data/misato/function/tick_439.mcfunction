schedule function misato:tick_440 1t
