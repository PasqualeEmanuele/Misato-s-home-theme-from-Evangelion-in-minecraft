schedule function misato:tick_361 1t
