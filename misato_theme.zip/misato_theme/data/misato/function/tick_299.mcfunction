schedule function misato:tick_300 1t
