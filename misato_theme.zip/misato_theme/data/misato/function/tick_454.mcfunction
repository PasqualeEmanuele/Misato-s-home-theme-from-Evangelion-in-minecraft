playsound minecraft:block.note_block.bass block @a ~ ~ ~ 1.0 0.5
playsound minecraft:block.note_block.flute block @a ~ ~ ~ 1.0 0.7937
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 0.93 1.5874
playsound minecraft:block.note_block.harp block @a ~ ~ ~ 0.91 1.4142
playsound minecraft:block.note_block.basedrum block @a ~ ~ ~ 1.0 0.7071
schedule function misato:tick_455 1t
