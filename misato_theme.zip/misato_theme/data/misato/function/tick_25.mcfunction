schedule function misato:tick_26 1t
