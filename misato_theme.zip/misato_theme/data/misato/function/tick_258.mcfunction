schedule function misato:tick_259 1t
