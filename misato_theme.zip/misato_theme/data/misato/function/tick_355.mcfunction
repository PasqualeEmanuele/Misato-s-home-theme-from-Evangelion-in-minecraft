schedule function misato:tick_356 1t
