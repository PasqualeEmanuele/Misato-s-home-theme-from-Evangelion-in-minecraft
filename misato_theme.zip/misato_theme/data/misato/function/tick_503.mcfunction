schedule function misato:tick_504 1t
