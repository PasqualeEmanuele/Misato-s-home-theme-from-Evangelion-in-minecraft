schedule function misato:tick_46 1t
