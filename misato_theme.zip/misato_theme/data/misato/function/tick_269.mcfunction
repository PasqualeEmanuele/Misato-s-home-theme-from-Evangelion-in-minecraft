schedule function misato:tick_270 1t
