schedule function misato:tick_486 1t
