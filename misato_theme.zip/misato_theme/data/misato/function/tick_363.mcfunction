schedule function misato:tick_364 1t
