schedule function misato:tick_517 1t
