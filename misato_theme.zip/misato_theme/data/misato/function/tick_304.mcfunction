schedule function misato:tick_305 1t
