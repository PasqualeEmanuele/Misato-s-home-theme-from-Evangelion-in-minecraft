schedule function misato:tick_297 1t
