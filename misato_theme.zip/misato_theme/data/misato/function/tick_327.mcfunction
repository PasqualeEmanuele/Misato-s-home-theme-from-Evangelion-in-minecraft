schedule function misato:tick_328 1t
