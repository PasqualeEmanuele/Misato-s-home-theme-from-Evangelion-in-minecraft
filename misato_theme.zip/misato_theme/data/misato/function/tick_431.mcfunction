schedule function misato:tick_432 1t
