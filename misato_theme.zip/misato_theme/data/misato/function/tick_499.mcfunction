playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.6 1.7818
schedule function misato:tick_500 1t
