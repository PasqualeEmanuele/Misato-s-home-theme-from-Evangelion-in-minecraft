schedule function misato:tick_342 1t
