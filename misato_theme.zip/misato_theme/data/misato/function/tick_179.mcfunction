playsound minecraft:block.note_block.flute block @a ~ ~ ~ 0.91 1.4142
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 1.0 1.4142
playsound minecraft:block.note_block.hat block @a ~ ~ ~ 0.68 1.4142
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.79 0.63
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.8 1.7818
schedule function misato:tick_180 1t
