schedule function misato:tick_512 1t
