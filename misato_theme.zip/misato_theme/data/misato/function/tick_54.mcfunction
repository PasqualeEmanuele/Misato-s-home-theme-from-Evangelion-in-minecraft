schedule function misato:tick_55 1t
