schedule function misato:tick_341 1t
