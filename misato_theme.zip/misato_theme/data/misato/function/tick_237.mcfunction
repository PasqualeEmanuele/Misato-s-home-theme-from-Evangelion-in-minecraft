schedule function misato:tick_238 1t
