schedule function misato:tick_347 1t
