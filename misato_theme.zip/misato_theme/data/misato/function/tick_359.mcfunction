schedule function misato:tick_360 1t
