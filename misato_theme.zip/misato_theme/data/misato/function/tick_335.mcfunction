playsound minecraft:block.note_block.flute block @a ~ ~ ~ 1.0 1.1892
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 1.0 1.1892
schedule function misato:tick_336 1t
