playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.8 1.7818
schedule function misato:tick_483 1t
