schedule function misato:tick_59 1t
