playsound minecraft:block.note_block.basedrum block @a ~ ~ ~ 0.9 0.7071
playsound minecraft:block.note_block.hat block @a ~ ~ ~ 0.72 1.4142
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.8 1.7818
schedule function misato:tick_12 1t
