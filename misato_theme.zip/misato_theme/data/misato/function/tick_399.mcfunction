schedule function misato:tick_400 1t
