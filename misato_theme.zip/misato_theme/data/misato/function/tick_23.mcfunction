schedule function misato:tick_24 1t
