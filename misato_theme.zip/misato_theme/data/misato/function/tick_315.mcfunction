playsound minecraft:block.note_block.flute block @a ~ ~ ~ 1.0 0.7937
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 1.0 1.5874
schedule function misato:tick_316 1t
