schedule function misato:tick_250 1t
