schedule function misato:tick_247 1t
