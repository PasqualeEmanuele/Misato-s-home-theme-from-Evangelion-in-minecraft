playsound minecraft:block.note_block.flute block @a ~ ~ ~ 1.0 0.8909
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 1.0 1.7818
playsound minecraft:block.note_block.hat block @a ~ ~ ~ 0.5 1.4142
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.61 1.7818
schedule function misato:tick_303 1t
