schedule function misato:tick_480 1t
