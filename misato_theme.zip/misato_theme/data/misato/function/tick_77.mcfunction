schedule function misato:tick_78 1t
