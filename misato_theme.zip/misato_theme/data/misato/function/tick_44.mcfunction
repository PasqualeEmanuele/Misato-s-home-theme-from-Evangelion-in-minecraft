schedule function misato:tick_45 1t
