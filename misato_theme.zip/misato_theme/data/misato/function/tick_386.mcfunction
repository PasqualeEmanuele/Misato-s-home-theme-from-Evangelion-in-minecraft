schedule function misato:tick_387 1t
