schedule function misato:tick_141 1t
