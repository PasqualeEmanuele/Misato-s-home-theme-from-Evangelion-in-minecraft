schedule function misato:tick_324 1t
