schedule function misato:tick_494 1t
