schedule function misato:tick_3 1t
