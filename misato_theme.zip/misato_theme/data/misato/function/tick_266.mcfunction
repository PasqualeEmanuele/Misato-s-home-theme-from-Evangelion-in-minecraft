schedule function misato:tick_267 1t
