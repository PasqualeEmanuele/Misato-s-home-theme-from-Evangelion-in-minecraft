playsound minecraft:block.note_block.flute block @a ~ ~ ~ 0.73 1.0595
playsound minecraft:block.note_block.hat block @a ~ ~ ~ 0.5 1.4142
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.6 1.7818
schedule function misato:tick_113 1t
