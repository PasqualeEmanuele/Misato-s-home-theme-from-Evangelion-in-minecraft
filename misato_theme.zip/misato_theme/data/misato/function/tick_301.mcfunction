schedule function misato:tick_302 1t
