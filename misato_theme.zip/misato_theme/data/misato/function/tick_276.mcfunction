schedule function misato:tick_277 1t
