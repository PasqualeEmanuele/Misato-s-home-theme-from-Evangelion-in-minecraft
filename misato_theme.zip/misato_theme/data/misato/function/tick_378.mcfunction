schedule function misato:tick_379 1t
