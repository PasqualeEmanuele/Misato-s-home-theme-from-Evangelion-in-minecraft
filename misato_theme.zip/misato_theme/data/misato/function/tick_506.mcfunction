playsound minecraft:block.note_block.flute block @a ~ ~ ~ 1.0 0.63
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 0.99 1.2599
schedule function misato:tick_507 1t
