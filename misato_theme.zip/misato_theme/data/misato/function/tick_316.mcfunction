schedule function misato:tick_317 1t
