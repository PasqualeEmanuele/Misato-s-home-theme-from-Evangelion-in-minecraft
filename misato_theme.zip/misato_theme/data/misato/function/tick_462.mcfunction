playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.61 1.7818
schedule function misato:tick_463 1t
