schedule function misato:tick_293 1t
