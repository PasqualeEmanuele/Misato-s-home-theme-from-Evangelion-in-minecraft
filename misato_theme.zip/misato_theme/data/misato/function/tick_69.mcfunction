schedule function misato:tick_70 1t
