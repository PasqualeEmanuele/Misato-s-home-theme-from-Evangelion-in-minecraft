schedule function misato:tick_40 1t
