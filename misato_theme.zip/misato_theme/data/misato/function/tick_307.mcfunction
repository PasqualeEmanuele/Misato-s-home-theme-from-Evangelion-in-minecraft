schedule function misato:tick_308 1t
