playsound minecraft:block.note_block.hat block @a ~ ~ ~ 0.71 1.4142
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.79 0.63
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.8 1.7818
schedule function misato:tick_132 1t
