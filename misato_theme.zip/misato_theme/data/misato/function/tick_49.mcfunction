schedule function misato:tick_50 1t
