schedule function misato:tick_66 1t
