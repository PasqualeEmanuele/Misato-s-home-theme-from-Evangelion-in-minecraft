playsound minecraft:block.note_block.bass block @a ~ ~ ~ 1.0 0.6674
playsound minecraft:block.note_block.flute block @a ~ ~ ~ 0.7 1.5874
playsound minecraft:block.note_block.harp block @a ~ ~ ~ 1.0 1.5874
playsound minecraft:block.note_block.harp block @a ~ ~ ~ 1.0 0.6674
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.73 1.7818
schedule function misato:tick_4 1t
