schedule function misato:tick_167 1t
