playsound minecraft:block.note_block.bass block @a ~ ~ ~ 1.0 0.5946
playsound minecraft:block.note_block.flute block @a ~ ~ ~ 1.0 0.7071
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 0.93 1.4142
playsound minecraft:block.note_block.harp block @a ~ ~ ~ 0.88 0.7071
playsound minecraft:block.note_block.harp block @a ~ ~ ~ 1.0 0.5946
playsound minecraft:block.note_block.basedrum block @a ~ ~ ~ 1.0 0.7071
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.74 1.3348
schedule function misato:tick_487 1t
