schedule function misato:tick_286 1t
