schedule function misato:tick_230 1t
