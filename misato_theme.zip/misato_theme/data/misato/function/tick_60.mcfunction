schedule function misato:tick_61 1t
