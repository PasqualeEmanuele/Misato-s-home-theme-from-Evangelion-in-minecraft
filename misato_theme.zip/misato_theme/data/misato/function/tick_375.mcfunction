schedule function misato:tick_376 1t
