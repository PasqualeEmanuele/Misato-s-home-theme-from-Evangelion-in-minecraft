schedule function misato:tick_143 1t
