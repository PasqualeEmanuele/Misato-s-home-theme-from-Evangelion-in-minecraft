schedule function misato:tick_296 1t
