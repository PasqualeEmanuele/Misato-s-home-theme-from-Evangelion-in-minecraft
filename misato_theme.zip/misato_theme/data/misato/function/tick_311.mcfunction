schedule function misato:tick_312 1t
