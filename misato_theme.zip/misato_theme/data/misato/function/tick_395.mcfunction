schedule function misato:tick_396 1t
