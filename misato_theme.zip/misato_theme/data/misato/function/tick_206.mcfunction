schedule function misato:tick_207 1t
