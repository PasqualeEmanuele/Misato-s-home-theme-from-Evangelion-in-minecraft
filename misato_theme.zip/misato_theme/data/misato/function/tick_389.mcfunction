schedule function misato:tick_390 1t
