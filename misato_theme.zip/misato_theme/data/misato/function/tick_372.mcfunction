schedule function misato:tick_373 1t
