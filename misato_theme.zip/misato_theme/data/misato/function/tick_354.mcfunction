schedule function misato:tick_355 1t
