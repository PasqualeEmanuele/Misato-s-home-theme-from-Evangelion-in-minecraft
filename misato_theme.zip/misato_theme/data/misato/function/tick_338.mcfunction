schedule function misato:tick_339 1t
