schedule function misato:tick_352 1t
