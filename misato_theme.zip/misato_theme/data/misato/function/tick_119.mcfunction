schedule function misato:tick_120 1t
