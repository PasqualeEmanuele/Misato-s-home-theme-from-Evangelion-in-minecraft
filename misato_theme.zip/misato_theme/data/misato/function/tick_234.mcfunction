schedule function misato:tick_235 1t
