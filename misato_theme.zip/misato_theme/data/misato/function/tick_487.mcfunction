schedule function misato:tick_488 1t
