schedule function misato:tick_35 1t
