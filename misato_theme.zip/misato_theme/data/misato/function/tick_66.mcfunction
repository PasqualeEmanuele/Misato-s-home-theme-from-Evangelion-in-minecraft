schedule function misato:tick_67 1t
