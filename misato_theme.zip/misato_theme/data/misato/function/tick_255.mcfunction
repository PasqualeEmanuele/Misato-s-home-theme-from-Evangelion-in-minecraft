schedule function misato:tick_256 1t
