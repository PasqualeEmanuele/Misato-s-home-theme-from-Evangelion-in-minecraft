playsound minecraft:block.note_block.flute block @a ~ ~ ~ 1.0 1.1225
schedule function misato:tick_334 1t
