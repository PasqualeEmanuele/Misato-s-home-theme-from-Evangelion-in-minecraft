schedule function misato:tick_307 1t
