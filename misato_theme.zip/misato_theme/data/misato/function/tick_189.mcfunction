schedule function misato:tick_190 1t
