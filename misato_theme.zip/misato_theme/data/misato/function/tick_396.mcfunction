schedule function misato:tick_397 1t
