playsound minecraft:block.note_block.flute block @a ~ ~ ~ 1.0 0.5297
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 1.0 1.0595
playsound minecraft:block.note_block.hat block @a ~ ~ ~ 0.53 1.4142
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.6 1.7818
schedule function misato:tick_271 1t
