schedule function misato:tick_146 1t
