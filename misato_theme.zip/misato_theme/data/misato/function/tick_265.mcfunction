playsound minecraft:block.note_block.flute block @a ~ ~ ~ 0.81 1.7818
schedule function misato:tick_266 1t
