playsound minecraft:block.note_block.bass block @a ~ ~ ~ 1.0 0.5946
playsound minecraft:block.note_block.basedrum block @a ~ ~ ~ 1.0 1.8877
schedule function misato:tick_383 1t
