playsound minecraft:block.note_block.bass block @a ~ ~ ~ 1.0 0.9439
playsound minecraft:block.note_block.harp block @a ~ ~ ~ 1.0 0.9439
playsound minecraft:block.note_block.harp block @a ~ ~ ~ 0.75 0.7071
playsound minecraft:block.note_block.harp block @a ~ ~ ~ 0.75 0.5946
playsound minecraft:block.note_block.hat block @a ~ ~ ~ 0.5 1.4142
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.61 1.7818
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.94 1.3348
schedule function misato:tick_391 1t
