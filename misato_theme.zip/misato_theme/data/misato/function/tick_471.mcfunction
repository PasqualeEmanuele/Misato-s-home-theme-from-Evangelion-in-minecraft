schedule function misato:tick_472 1t
