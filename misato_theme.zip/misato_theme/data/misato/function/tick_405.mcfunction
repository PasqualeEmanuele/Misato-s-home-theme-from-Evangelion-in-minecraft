schedule function misato:tick_406 1t
