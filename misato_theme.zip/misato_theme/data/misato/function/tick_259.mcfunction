playsound minecraft:block.note_block.bass block @a ~ ~ ~ 1.0 0.5297
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.99 0.63
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.8 1.7818
schedule function misato:tick_260 1t
