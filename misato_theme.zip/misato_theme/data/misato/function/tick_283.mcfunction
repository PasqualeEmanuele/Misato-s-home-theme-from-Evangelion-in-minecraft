schedule function misato:tick_284 1t
