schedule function misato:tick_502 1t
