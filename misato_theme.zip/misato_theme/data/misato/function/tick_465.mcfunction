playsound minecraft:block.note_block.flute block @a ~ ~ ~ 1.0 0.8909
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 0.93 1.7818
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.61 0.63
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.8 1.4142
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 1.0 0.8909
schedule function misato:tick_466 1t
