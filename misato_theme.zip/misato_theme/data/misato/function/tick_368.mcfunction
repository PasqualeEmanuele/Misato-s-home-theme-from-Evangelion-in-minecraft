schedule function misato:tick_369 1t
