playsound minecraft:block.note_block.basedrum block @a ~ ~ ~ 1.0 0.7071
schedule function misato:tick_503 1t
