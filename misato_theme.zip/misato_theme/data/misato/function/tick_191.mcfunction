schedule function misato:tick_192 1t
