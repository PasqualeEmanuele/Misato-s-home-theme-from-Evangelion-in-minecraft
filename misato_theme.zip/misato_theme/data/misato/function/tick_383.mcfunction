schedule function misato:tick_384 1t
