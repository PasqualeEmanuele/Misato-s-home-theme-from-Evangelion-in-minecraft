schedule function misato:tick_30 1t
