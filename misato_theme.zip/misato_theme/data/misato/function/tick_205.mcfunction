schedule function misato:tick_206 1t
