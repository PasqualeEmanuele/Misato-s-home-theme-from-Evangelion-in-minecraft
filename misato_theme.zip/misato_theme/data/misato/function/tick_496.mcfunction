schedule function misato:tick_497 1t
