schedule function misato:tick_315 1t
