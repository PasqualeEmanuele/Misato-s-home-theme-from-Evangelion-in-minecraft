schedule function misato:tick_43 1t
