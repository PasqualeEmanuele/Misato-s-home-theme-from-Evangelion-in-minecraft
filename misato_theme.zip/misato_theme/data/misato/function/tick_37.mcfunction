schedule function misato:tick_38 1t
