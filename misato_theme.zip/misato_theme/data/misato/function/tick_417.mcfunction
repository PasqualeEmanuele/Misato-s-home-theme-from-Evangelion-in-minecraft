playsound minecraft:block.note_block.flute block @a ~ ~ ~ 1.0 1.1892
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 0.97 1.1892
playsound minecraft:block.note_block.harp block @a ~ ~ ~ 1.0 1.5874
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.73 1.4142
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 1.0 0.8909
schedule function misato:tick_418 1t
