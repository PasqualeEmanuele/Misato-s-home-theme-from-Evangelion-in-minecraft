playsound minecraft:block.note_block.flute block @a ~ ~ ~ 0.87 1.3348
schedule function misato:tick_111 1t
