schedule function misato:tick_470 1t
