playsound minecraft:block.note_block.flute block @a ~ ~ ~ 1.0 0.8409
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 0.93 1.6818
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.61 1.7818
schedule function misato:tick_431 1t
