schedule function misato:tick_430 1t
