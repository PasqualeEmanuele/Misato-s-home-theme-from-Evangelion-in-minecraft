playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.58 1.0595
schedule function misato:tick_9 1t
