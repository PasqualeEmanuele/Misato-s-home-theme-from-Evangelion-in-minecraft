schedule function misato:tick_292 1t
