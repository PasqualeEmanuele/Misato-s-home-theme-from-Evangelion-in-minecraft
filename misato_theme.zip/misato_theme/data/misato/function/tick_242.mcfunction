schedule function misato:tick_243 1t
