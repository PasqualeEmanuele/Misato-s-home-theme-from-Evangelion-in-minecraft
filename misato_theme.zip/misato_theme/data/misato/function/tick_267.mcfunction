schedule function misato:tick_268 1t
