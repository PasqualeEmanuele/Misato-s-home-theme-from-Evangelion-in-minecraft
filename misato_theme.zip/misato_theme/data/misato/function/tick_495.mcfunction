schedule function misato:tick_496 1t
