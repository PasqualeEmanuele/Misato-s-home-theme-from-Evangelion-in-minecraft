schedule function misato:tick_382 1t
