playsound minecraft:block.note_block.bass block @a ~ ~ ~ 1.0 0.7071
playsound minecraft:block.note_block.flute block @a ~ ~ ~ 0.95 1.5874
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 1.0 1.7818
playsound minecraft:block.note_block.harp block @a ~ ~ ~ 0.92 1.0595
playsound minecraft:block.note_block.hat block @a ~ ~ ~ 0.5 1.4142
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.81 1.4142
schedule function misato:tick_137 1t
