schedule function misato:tick_372 1t
