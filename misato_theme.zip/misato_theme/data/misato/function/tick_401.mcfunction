playsound minecraft:block.note_block.flute block @a ~ ~ ~ 1.0 0.7937
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 0.93 1.5874
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.7 1.4142
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 1.0 0.8909
schedule function misato:tick_402 1t
