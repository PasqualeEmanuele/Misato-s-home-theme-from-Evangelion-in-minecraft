schedule function misato:tick_310 1t
