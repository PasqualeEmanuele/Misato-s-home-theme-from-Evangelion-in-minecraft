schedule function misato:tick_144 1t
