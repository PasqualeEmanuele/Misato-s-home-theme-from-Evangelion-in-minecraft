schedule function misato:tick_7 1t
