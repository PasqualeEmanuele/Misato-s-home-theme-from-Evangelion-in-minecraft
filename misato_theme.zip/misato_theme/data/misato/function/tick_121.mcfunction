schedule function misato:tick_122 1t
