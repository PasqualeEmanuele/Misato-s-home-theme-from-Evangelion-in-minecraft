schedule function misato:tick_469 1t
