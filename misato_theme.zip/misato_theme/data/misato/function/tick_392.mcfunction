schedule function misato:tick_393 1t
