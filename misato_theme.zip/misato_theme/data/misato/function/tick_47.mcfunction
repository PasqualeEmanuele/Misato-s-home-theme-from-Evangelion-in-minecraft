schedule function misato:tick_48 1t
