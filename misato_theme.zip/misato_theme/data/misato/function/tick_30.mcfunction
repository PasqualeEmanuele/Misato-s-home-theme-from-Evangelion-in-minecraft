schedule function misato:tick_31 1t
