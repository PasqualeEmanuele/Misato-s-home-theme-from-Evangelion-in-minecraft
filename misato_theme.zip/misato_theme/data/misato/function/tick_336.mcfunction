schedule function misato:tick_337 1t
