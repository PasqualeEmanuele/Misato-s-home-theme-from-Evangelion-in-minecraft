schedule function misato:tick_251 1t
