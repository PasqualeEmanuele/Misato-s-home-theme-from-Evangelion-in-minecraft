playsound minecraft:block.note_block.harp block @a ~ ~ ~ 0.75 0.8909
playsound minecraft:block.note_block.harp block @a ~ ~ ~ 0.75 0.5946
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.8 1.7818
schedule function misato:tick_490 1t
