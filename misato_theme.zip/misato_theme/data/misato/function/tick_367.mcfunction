schedule function misato:tick_368 1t
