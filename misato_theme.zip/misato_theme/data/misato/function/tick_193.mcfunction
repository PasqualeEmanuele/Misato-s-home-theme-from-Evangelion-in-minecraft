schedule function misato:tick_194 1t
