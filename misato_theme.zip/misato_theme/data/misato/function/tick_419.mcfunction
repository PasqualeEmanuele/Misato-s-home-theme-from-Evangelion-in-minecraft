schedule function misato:tick_420 1t
