schedule function misato:tick_477 1t
