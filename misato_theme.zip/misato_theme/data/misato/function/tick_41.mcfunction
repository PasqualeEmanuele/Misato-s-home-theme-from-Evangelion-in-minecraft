schedule function misato:tick_42 1t
