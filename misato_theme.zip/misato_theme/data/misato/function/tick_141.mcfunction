schedule function misato:tick_142 1t
