schedule function misato:tick_381 1t
