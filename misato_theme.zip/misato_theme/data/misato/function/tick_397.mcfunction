schedule function misato:tick_398 1t
