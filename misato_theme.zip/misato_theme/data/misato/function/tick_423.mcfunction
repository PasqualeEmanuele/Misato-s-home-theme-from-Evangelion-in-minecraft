schedule function misato:tick_424 1t
