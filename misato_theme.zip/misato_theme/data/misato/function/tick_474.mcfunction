playsound minecraft:block.note_block.snare block @a ~ ~ ~ 1.0 0.63
schedule function misato:tick_475 1t
