schedule function misato:tick_505 1t
