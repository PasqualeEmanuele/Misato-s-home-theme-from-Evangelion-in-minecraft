playsound minecraft:block.note_block.basedrum block @a ~ ~ ~ 1.0 0.7071
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.6 1.7818
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 1.0 0.7937
schedule function misato:tick_495 1t
