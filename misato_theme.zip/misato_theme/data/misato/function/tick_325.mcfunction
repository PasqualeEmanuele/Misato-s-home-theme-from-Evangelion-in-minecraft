schedule function misato:tick_326 1t
