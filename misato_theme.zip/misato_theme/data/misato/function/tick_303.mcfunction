schedule function misato:tick_304 1t
