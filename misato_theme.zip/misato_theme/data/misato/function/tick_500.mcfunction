schedule function misato:tick_501 1t
