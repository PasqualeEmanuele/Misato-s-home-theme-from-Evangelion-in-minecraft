schedule function misato:tick_392 1t
