schedule function misato:tick_489 1t
