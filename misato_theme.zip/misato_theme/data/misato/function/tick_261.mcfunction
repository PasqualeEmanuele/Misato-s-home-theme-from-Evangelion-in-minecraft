schedule function misato:tick_262 1t
