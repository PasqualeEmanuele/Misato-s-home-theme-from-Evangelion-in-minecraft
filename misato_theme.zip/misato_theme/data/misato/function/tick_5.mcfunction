schedule function misato:tick_6 1t
