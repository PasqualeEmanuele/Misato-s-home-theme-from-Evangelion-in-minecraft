schedule function misato:tick_160 1t
