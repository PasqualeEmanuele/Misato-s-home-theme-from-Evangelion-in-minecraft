schedule function misato:tick_106 1t
