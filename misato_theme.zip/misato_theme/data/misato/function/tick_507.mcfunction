schedule function misato:tick_508 1t
