schedule function misato:tick_417 1t
