schedule function misato:tick_374 1t
