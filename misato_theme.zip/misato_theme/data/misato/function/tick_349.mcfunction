schedule function misato:tick_350 1t
