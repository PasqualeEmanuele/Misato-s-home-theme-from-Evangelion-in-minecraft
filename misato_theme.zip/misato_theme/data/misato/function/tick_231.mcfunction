schedule function misato:tick_232 1t
