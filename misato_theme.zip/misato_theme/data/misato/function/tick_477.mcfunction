schedule function misato:tick_478 1t
