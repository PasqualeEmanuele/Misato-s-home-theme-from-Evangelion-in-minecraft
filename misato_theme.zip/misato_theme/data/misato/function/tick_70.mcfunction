schedule function misato:tick_71 1t
