schedule function misato:tick_248 1t
