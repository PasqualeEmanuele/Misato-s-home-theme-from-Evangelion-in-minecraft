schedule function misato:tick_234 1t
