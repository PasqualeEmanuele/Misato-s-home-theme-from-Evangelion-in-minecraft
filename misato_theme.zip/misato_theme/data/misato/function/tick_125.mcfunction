schedule function misato:tick_126 1t
