schedule function misato:tick_226 1t
