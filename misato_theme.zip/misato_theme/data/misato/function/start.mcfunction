function misato:tick_0
