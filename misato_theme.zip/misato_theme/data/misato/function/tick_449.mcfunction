playsound minecraft:block.note_block.flute block @a ~ ~ ~ 1.0 0.7071
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 0.93 1.4142
playsound minecraft:block.note_block.harp block @a ~ ~ ~ 1.0 1.6818
playsound minecraft:block.note_block.snare block @a ~ ~ ~ 0.71 1.4142
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 0.99 0.8909
schedule function misato:tick_450 1t
