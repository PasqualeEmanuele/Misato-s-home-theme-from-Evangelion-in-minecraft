schedule function misato:tick_344 1t
