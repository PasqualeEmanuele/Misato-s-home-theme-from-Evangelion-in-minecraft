schedule function misato:tick_388 1t
