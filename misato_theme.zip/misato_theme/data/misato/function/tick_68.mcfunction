schedule function misato:tick_69 1t
