schedule function misato:tick_294 1t
