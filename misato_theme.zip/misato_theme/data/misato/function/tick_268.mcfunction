schedule function misato:tick_269 1t
