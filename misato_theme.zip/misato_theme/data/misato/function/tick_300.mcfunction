schedule function misato:tick_301 1t
