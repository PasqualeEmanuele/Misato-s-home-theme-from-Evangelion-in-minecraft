playsound minecraft:block.note_block.bass block @a ~ ~ ~ 1.0 0.7071
playsound minecraft:block.note_block.flute block @a ~ ~ ~ 0.8 1.7818
playsound minecraft:block.note_block.harp block @a ~ ~ ~ 1.0 1.7818
playsound minecraft:block.note_block.harp block @a ~ ~ ~ 1.0 0.7071
schedule function misato:tick_8 1t
