schedule function misato:tick_255 1t
