schedule function misato:tick_395 1t
