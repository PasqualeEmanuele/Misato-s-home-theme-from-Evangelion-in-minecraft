schedule function misato:tick_332 1t
