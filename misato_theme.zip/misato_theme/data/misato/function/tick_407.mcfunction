schedule function misato:tick_408 1t
