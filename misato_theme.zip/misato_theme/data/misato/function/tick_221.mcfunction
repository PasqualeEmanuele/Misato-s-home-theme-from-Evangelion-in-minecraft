schedule function misato:tick_222 1t
