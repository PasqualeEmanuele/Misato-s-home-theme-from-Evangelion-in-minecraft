playsound minecraft:block.note_block.flute block @a ~ ~ ~ 1.0 0.7071
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 0.93 1.4142
playsound minecraft:block.note_block.basedrum block @a ~ ~ ~ 1.0 0.7071
playsound minecraft:block.note_block.cow_bell block @a ~ ~ ~ 1.0 0.6674
schedule function misato:tick_498 1t
