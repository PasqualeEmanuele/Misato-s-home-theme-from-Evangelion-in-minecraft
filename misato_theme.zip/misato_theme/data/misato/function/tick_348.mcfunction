schedule function misato:tick_349 1t
