schedule function misato:tick_422 1t
