schedule function misato:tick_39 1t
