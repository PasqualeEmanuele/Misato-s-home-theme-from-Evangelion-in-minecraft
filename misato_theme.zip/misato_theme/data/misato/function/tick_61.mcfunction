schedule function misato:tick_62 1t
