schedule function misato:tick_320 1t
