schedule function misato:tick_18 1t
