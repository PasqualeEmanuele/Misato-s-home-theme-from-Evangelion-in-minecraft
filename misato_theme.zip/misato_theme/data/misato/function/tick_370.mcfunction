schedule function misato:tick_371 1t
