schedule function misato:tick_216 1t
