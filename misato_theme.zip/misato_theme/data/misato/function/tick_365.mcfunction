schedule function misato:tick_366 1t
