schedule function misato:tick_345 1t
