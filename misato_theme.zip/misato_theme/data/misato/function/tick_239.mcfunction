playsound minecraft:block.note_block.flute block @a ~ ~ ~ 0.77 1.1892
schedule function misato:tick_240 1t
