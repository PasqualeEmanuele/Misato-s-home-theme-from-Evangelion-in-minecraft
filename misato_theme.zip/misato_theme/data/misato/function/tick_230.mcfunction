schedule function misato:tick_231 1t
