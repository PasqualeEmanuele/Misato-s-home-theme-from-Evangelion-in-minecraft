schedule function misato:tick_72 1t
