schedule function misato:tick_197 1t
