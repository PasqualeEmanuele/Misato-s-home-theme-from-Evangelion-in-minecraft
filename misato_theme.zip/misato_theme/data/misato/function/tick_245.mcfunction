schedule function misato:tick_246 1t
