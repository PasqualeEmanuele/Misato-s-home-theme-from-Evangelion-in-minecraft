schedule function misato:tick_195 1t
