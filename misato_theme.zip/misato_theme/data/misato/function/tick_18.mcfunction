schedule function misato:tick_19 1t
